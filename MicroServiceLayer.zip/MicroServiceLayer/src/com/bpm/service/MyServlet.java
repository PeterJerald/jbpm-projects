package com.bpm.service;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MyServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		System.out.println("Got HIt********************  ");	
		String fileName = (String) request.getParameter("file");
		if (fileName == null || fileName.equals(""))
			throw new ServletException(
					"Invalid or non-existent file parameter in SendXml servlet.");

		if (fileName.indexOf(".xml") == -1)
			fileName = fileName + ".xml";

		ServletOutputStream stream = null;
		BufferedInputStream buf = null;
		try {

			/*stream = response.getOutputStream();
			//InputStream fileStream=request.getSession().getServletContext().getResourceAsStream(fileName);
			//System.out.println("File Avaiable  :"+fileStream.available());
			File xml = new File("D:\\softwares\\eclipse\\workspace\\MicroServiceLayer\\WebContent\\content.xml");

			response.setContentType("text/xml");

			response.addHeader("Content-Disposition", "attachment; filename="
					+ fileName);

			response.setContentLength((int) xml.length()); 

			//FileInputStream input = new FileInputStream(fileStream);
			//buf = new BufferedInputStream(fileStream);
			FileInputStream input = new FileInputStream(xml);
			buf = new BufferedInputStream(input);
			int readBytes = 0;
			String output=null;

			// read from the file; write to the ServletOutputStream
			while ((readBytes = buf.read()) != -1){
				output+=output;
			}
				//stream.write(readBytes);
*/			
			BufferedReader br=new BufferedReader(new FileReader(new File("D:\\softwares\\eclipse\\workspace\\MicroServiceLayer\\WebContent\\content.xml")));
			String output;
			StringBuilder sb=new StringBuilder();
			while((output=br.readLine())!=null){
				sb.append(output.trim());
			}
			response.getWriter().write(sb.toString());

		} catch (IOException ioe) {

			throw new ServletException(ioe.getMessage());

		} catch (Exception e) {
			e.printStackTrace();
			throw new ServletException(e.getMessage());
		}
		finally {

			if (stream != null)
				stream.close();
			if (buf != null)
				buf.close();
		}

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}
}
