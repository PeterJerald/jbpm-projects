package com.bpm.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Testing {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(
				new FileReader(
						new File(
								"D:\\softwares\\eclipse\\workspace\\MicroServiceLayer\\WebContent\\content.xml")));
		String output;
		StringBuilder sb = new StringBuilder();
		while ((output = br.readLine()) != null) {
			sb.append(output.trim());
		}

		System.out.println(sb.toString());
	}

}
