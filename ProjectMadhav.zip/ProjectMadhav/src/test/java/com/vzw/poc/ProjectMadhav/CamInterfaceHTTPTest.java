package com.vzw.poc.ProjectMadhav;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.switchyard.component.test.mixins.cdi.CDIMixIn;
import org.switchyard.component.test.mixins.http.HTTPMixIn;
import org.switchyard.test.BeforeDeploy;
import org.switchyard.test.Invoker;
import org.switchyard.test.ServiceOperation;
import org.switchyard.test.SwitchYardRunner;
import org.switchyard.test.SwitchYardTestCaseConfig;
import org.switchyard.test.SwitchYardTestKit;

@RunWith(SwitchYardRunner.class)
@SwitchYardTestCaseConfig(config = SwitchYardTestCaseConfig.SWITCHYARD_XML, mixins = {
		CDIMixIn.class, HTTPMixIn.class })
public class CamInterfaceHTTPTest {

	private HTTPMixIn http;
	@ServiceOperation("CamInterface")
	private Invoker service;

	private static final String BASE_URL = "http://localhost:8081/ProjectMadhav";

	@BeforeDeploy
	public void setProperties() {
		System.setProperty("org.switchyard.component.http.standalone.port",
				"8081");
	}

	/*@Test
	public void testProcessOrchFlowSpringDSLL() throws Exception {
		http.initialize();
		http.setContentType("text/plain");
		String response = http.sendString(BASE_URL+"/Post-XML",
				"<xml><message>hello</message></xml>", HTTPMixIn.HTTP_POST);
		System.out.println("Response :" + response);
	}*/
	

	@Test
	public void testProcessOrchFlowJavaDSL() throws Exception {
		http.initialize();
		http.setContentType("text/plain");
		String response = http.sendString(BASE_URL,
				"<xml><message>hello</message></xml>", HTTPMixIn.HTTP_POST);
		System.out.println("Response :" + response);
	}
}
