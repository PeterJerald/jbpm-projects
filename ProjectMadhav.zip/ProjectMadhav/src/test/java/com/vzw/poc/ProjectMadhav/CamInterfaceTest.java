package com.vzw.poc.ProjectMadhav;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.switchyard.component.test.mixins.cdi.CDIMixIn;
import org.switchyard.test.Invoker;
import org.switchyard.test.ServiceOperation;
import org.switchyard.test.SwitchYardRunner;
import org.switchyard.test.SwitchYardTestCaseConfig;
import org.switchyard.test.SwitchYardTestKit;

@RunWith(SwitchYardRunner.class)
@SwitchYardTestCaseConfig(config = SwitchYardTestCaseConfig.SWITCHYARD_XML, mixins = { CDIMixIn.class })
public class CamInterfaceTest {

	private SwitchYardTestKit testKit;
	private CDIMixIn cdiMixIn;
	@ServiceOperation("CamInterface")
	private Invoker service;

	@Test
	public void testProcessOrchFlow() throws Exception {
		// TODO Auto-generated method stub
		// initialize your test message
		String message = "Hi";
		String result = service.operation("processOrchFlow").sendInOut(message)
				.getContent(String.class);
		System.out.println("result :"+result);
		// validate the results
		Assert.assertTrue("Implement me", true);
	}

}
