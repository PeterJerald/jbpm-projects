package com.vzw.poc.ProjectMadhav;

public interface ProcessInterface {
	
	public String launchFallout(FalloutBO bo);

}
