package com.vzw.poc.ProjectMadhav;

public interface CamInterface {
	
	public String processOrchFlow(String msg);

}
