package com.vzw.poc.ProjectMadhav;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.xml.namespace.QName;

import org.kie.api.task.model.TaskSummary;
import org.switchyard.component.bpm.runtime.BPMTaskService;
import org.switchyard.component.bpm.runtime.BPMTaskServiceRegistry;

@ManagedBean(name = "falloutService")
@SessionScoped
public class FalloutService {

	private final BPMTaskService _taskService;
	private final List<TaskSummary> _userTasks;
	private final Map<Long, FalloutBO> _userTickets;
	private String _userId = "admin";
	
    private static final String falloutBO = "falloutBo";
    private static final String EN_UK = "en-UK";

	public FalloutService() {

		_taskService = BPMTaskServiceRegistry.getTaskService(new QName(null,
				"ProjectMadhav"), new QName(
				"urn:com.vzw.poc:ProjectMadhav:1.0", "ProcessInterface"));
		_userTasks = Collections.synchronizedList(new ArrayList<TaskSummary>());
		_userTickets = Collections
				.synchronizedMap(new LinkedHashMap<Long, FalloutBO>());
	}

	public String get_userId() {
		return _userId;
	}

	public void set_userId(String _userId) {
		this._userId = _userId;
	}
	
	public List<TaskSummary> getUserTasks() {
        return _userTasks;
    }

    public Map<Long, FalloutBO> getUserTickets() {
        return _userTickets;
    }

	private void fetchTasks() {
		synchronized (_userTasks) {
			_userTasks.clear();
			_userTickets.clear();
			List<TaskSummary> tasks = _taskService.getTasksAssignedAsPotentialOwner(_userId, EN_UK);
			for (TaskSummary task : tasks) {
				_userTasks.add(task);
				Map<String, Object> params = _taskService.getTaskContent(task
						.getId());
				FalloutBO fallout = (FalloutBO) params.get(falloutBO);
				_userTickets.put(task.getProcessInstanceId(), fallout);
			}
		}
	}

}
