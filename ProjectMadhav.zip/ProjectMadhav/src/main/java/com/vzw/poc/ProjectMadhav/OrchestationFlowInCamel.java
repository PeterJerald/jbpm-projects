package com.vzw.poc.ProjectMadhav;

import org.apache.camel.builder.RouteBuilder;

public class OrchestationFlowInCamel extends RouteBuilder {

	/**
	 * The Camel route is configured via this method. The from endpoint is
	 * required to be a SwitchYard service.
	 */
	public void configure() {
		// TODO Auto-generated method stub
		System.out.println("Got hit ****************************");
		from("switchyard://CamInterface")
				.log("Received message for 'CamInterface' : ${body}").choice()
				.when().xpath("//xml/message = 'launchFallout'").to("switchyard://ProcessInterface")
				.otherwise()
				.log("Received message : ${body}, so not launching fallout .");
	}
}
