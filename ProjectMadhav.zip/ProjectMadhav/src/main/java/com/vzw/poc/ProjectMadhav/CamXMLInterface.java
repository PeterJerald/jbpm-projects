package com.vzw.poc.ProjectMadhav;

public interface CamXMLInterface {
	
	public String processOrchFlow(String message);

}
