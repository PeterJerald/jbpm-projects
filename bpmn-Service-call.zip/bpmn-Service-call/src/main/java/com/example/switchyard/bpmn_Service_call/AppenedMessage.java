package com.example.switchyard.bpmn_Service_call;

public interface AppenedMessage {
	
	public String appendMsg(String str);

}
