package com.example.switchyard.bpmn_Service_call;

import org.switchyard.component.bean.Service;

@Service(AppenedMessage.class)
public class AppenedMessageBean implements AppenedMessage {

	@Override
	public String appendMsg(String str) {
		// TODO Auto-generated method stub
		return str + " Bean Message ......";
	}

}
